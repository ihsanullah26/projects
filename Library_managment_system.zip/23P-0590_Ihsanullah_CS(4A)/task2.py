from neo4j import GraphDatabase

# Connect to the database
driver = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", ""))

with driver.session() as session:
    title = input("Enter movie title: ")

    query = """
        MATCH (m:Movie {title: $title})
        RETURN m
    """
    result = session.run(query, title=title)

    record = result.single()

    if record:
        movie = record["m"]
        print("Title:", movie.get("title"))
        print("Overview:", movie.get("overview"))
        print("Runtime:", movie.get("runtime"))
        print("Release Date:", movie.get("release_date"))
        print("Vote Average:", movie.get("vote_average"))
    else:
        print("Movie not found.")

driver.close()
