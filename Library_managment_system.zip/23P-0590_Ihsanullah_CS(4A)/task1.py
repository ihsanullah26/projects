from tkinter import *
from tkinter import ttk,messagebox
from pymongo import MongoClient
from tkinter import simpledialog # for deleting Records
import tkinter as tk
# making connection with mongodb
client=MongoClient("mongodb://localhost:27017/")
database=client["Library_Managment_System"]
Book_collections=database["Books"]
Lending_collections=database["Lendings"]

root = Tk()
root.title("Library Management System")
root.geometry("1000x600")
root.resizable(False, False)
root.configure(bg='black')
# Create a style for the tabs
style = ttk.Style()
style.theme_use('default')
style.configure('TNotebook', background='black', borderwidth=0)
style.configure('TNotebook.Tab', background='black', foreground='white', padding=[10, 5])
style.map('TNotebook.Tab', background=[('selected', 'gray')])

# Create Tabs
Tabs = ttk.Notebook(root)
    
# making tabs
book_tab = ttk.Frame(Tabs)
Lending_tab = ttk.Frame(Tabs)
Show_book = tk.Frame(Tabs)
Show_lending = tk.Frame(Tabs)

Tabs.add(book_tab, text="Add Book")
Tabs.add(Show_book, text="View Book")
Tabs.add(Lending_tab, text="Lend A Book")
Tabs.add(Show_lending, text="View Lending Records")
Tabs.pack(fill='both', expand=True)

Show_book.configure(bg='skyblue')
Show_lending.configure(bg='skyblue')
#function to Add a new Boot
def Add_Book():
    if not title_entry.get():
        messagebox.showerror("Error","Title is mendatory")
        return
    Book= {
            "Title":title_entry.get(),
            "Author":author_entry.get(),
            "Genre":Genre_entry.get(),
            "Quantity":int(quantity_entry.get())
    }
    Book_collections.insert_one(Book)
    messagebox.showinfo("Success", "Book added successfully!")
    view_book()
#function to delete a book by title
def delete_book_by_title():
   selectedItem=book_tree.selection()
   if not selectedItem:
       messagebox.showerror("Error","Please Select Some Book to Delete")
       return;
   
   values=book_tree.item(selectedItem[0],'values')
   title=values[0]
   cofirmation=messagebox.askyesno("Confirm Deletion",f"Are You Sure want to Delete '{title}'?")
   if cofirmation:
        result=Book_collections.find_one({"Title":title})
        if result:
           Book_collections.delete_one({"_id":result["_id"]})
           messagebox.showinfo("Success",f"Book '{title}' Deleted Successfully.")
           view_book()
        else:
            messagebox.showerror("Error","Exiting")
    
#function to View Book
def view_book():
    for i in book_tree.get_children():
        book_tree.delete(i)
    for book in Book_collections.find():
        book_tree.insert('','end',values=(book["Title"],book["Author"],book["Genre"],book["Quantity"]))
        
#Function to Clear The field of Book Tab
def ClearBookField():
    title_entry.delete(0, END)
    author_entry.delete(0, END)
    Genre_entry.delete(0, END)
    quantity_entry.delete(0, END)
        
# making a Form Like for Adding Book
# Title Label (Main Heading)
heading = Label(book_tab, text="Add Book", fg="white", bg="black", font=("Times New Roman", 24, "bold"))
heading.grid(row=0, column=0, pady=40,sticky=W)

# Book Title
ttk.Label(book_tab, text="Title:" ,font=("Times New Roman", 16, "bold")).grid(row=1, column=0, padx=1, pady=10, sticky=W)
title_entry = Entry(book_tab, font=("Times New Roman", 16), width=30)
title_entry.grid(row=1, column=1, padx=10, pady=10)

# Book Author
ttk.Label(book_tab, text="Author:" ,font=("Times New Roman", 16, "bold")).grid(row=2, column=0, padx=1, pady=10, sticky=W)
author_entry = Entry(book_tab, font=("Times New Roman", 16), width=30)
author_entry.grid(row=2, column=1, padx=1, pady=10)

#Book Genre
ttk.Label(book_tab,text="Genre:",font=("Times New Roman",16,"bold")).grid(row=3,column=0,padx=1,pady=10,sticky=W)
Genre_entry=Entry(book_tab,font=("Times New Roman",16),width=30)
Genre_entry.grid(row=3,column=1,padx=10,pady=10)

#Book Quantity
ttk.Label(book_tab,text="Quantity:",font=("Times New Roman",16,"bold")).grid(row=4,column=0,padx=1,pady=10,sticky=W)
quantity_entry=Entry(book_tab,font=("Times New Roman",16),width=30)
quantity_entry.grid(row=4,column=1,padx=10,pady=10)

AddBook_button=Button(book_tab,text="Click to Add Book",bg="Yellow",fg="black",font=("Times New Roman",16,"bold"),command=Add_Book)
AddBook_button.grid(row=6,column=0,padx=10,pady=10,sticky=E)

#button to Ask from user about a book title and delete it
DeleteBook_button = Button(Show_book, text="Delete Selected Book", bg="Yellow", fg="black",font=("Times New Roman", 16, "bold"), command=delete_book_by_title)
DeleteBook_button.grid(row=6, column=0, padx=10, pady=10, sticky=W)

ClearButtonINBook=Button(book_tab,text="Clear Fields",bg="Yellow",fg="black",font=("Times New Roman",18,"bold"),command=ClearBookField)
ClearButtonINBook.grid(row=6,column=1,padx=10,pady=10,sticky=E)

#to Show Books in new Tab
book_tree=ttk.Treeview(Show_book,columns=("Title","Author","Genre","Quantity"),show='headings')
for record in ("Title","Author","Genre","Quantity"):
    book_tree.heading(record,text=record)
book_tree.grid(row=2,column=0,columnspan=6,pady=10)
view_book();
################################################from here onword Lend records is Tackled######
def AddLendingrecord():
    title=Book_title_entry.get()
    borrower=Borrower_name_entry.get()
    bdate=Borrow_date_entry.get()
    RDate=return_date_entry.get()
    
    book=Book_collections.find_one({"Title":title})
    if not book:
        messagebox.showerror("Error","Book Not FOund")
        return
    if book["Quantity"] <=0:
        messagebox.showwarning("Unavailable","No Copies Available to Lend")
        return
    record={
        "Book_title":title,
        "Borrower_Name":borrower,
        "Borrow_date":bdate,
        "Return_date":RDate
    }
    Lending_collections.insert_one(record)
    
    Book_collections.update_one({"Title":title},{"$inc":{"Quantity":-1}})
    messagebox.showinfo("Success","Book Lend Successfully.")
    view_LendingRecord()
    view_book()

###################function to handle delete Lending record#########################
def Delete_Lending():
    selectedLend=Lending_tree.selection()
    if not selectedLend:
        messagebox.showerror("Error","Please Select Some record to Delete")
        return;
    value=Lending_tree.item(selectedLend[0],'values')
    borrow_title=value[0]
    askConfirmation=messagebox.askyesno("Confirm Deletion",f"Are you Sure to Delete '{borrow_title}'?")
    if askConfirmation:
        findRecord=Lending_collections.find_one({"Book_title":borrow_title})
        Lending_collections.delete_one({"_id":findRecord["_id"]})
        messagebox.showinfo("Success","Record Deleted Successfully")
        Book_collections.update_one({"Title":borrow_title},{"$inc":{"Quantity":1}})

        view_LendingRecord()
        view_book()
    else:
         messagebox.showwarning("Warning","Exiting")
         view_LendingRecord()   

###########function to update the return date #####################
def update_return_date():
    selected=Lending_tree.selection()
    if not selected:
        messagebox.showerror("Error","Please Select a Record to Update return Date")
        return;
    values=Lending_tree.item(selected[0],'values')
    book_title=values[0]
    borrow_name=values[1]
    
    new_return_date=simpledialog.askstring("Update Return Date","Enter new Return Date: ")
    if new_return_date:
        result=Lending_collections.update_one({"Book_title":book_title,"Borrower_Name":borrow_name},{"$set":{"Return_date":new_return_date}})
        messagebox.showinfo("Success","Date Update successfully")
        view_LendingRecord()
    else:
        messagebox.showerror("Error","Updated value not Entered")
        view_LendingRecord()
       
            
##########################End of Function######################
def view_LendingRecord():
    for i in Lending_tree.get_children():
        Lending_tree.delete(i)
    for LendingRecords in Lending_collections.find():
        Lending_tree.insert('','end',values=(LendingRecords["Book_title"],LendingRecords["Borrower_Name"],LendingRecords["Borrow_date"],LendingRecords["Return_date"]))

###################End of Function#####################
#function to Clear fields of Lending tab
def ClearLendingTabs():
    Book_title_entry.delete(0,END)
    Borrower_name_entry.delete(0,END)
    Borrow_date_entry.delete(0,END)
    return_date_entry.delete(0,END)
 ###############################################
LendLabel=Label(Lending_tab,text="Enter Information",bg="black",fg="white",font=("Times New Roman",18,"bold"))
LendLabel.grid(row=0,column=0,pady=40,sticky=W)
#Label and Entry for Book Title
ttk.Label(Lending_tab,text="Book Title:",font=("Times New Roman",16,"bold")).grid(row=1,column=0,padx=1,pady=10,sticky=W)
Book_title_entry=Entry(Lending_tab,font=("Times New Roman",16,"bold"),width=30)
Book_title_entry.grid(row=1,column=1,padx=10,pady=10)

#Label and Entry for Borrower name
ttk.Label(Lending_tab,text="Name:",font=("Times New Roman",16,"bold")).grid(row=2,column=0,padx=1,pady=10,sticky=W)
Borrower_name_entry=Entry(Lending_tab,font=("Times New Roman",16,"bold"),width=30)
Borrower_name_entry.grid(row=2,column=1)

#Label and Entry for Borrow Date
ttk.Label(Lending_tab,text="Borrow Date:",font=("Times New Roman",16,"bold")).grid(row=3,column=0,padx=1,pady=10,sticky=W)
Borrow_date_entry=Entry(Lending_tab,font=("Times New Roman",16,"bold"),width=30)
Borrow_date_entry.grid(row=3,column=1)

#Label and Entry for Return Date
ttk.Label(Lending_tab,text="Return Date:",font=("Times New Roman",16,"bold")).grid(row=4,column=0,padx=1,pady=10,sticky=W)
return_date_entry=Entry(Lending_tab,font=("Times New Roman",16,"bold"),width=30)
return_date_entry.grid(row=4,column=1)

AddLend_button=Button(Lending_tab,text="Add Lending Record",bg="Yellow",fg="black",font=("Times New Roman",16,"bold"),command=AddLendingrecord)
AddLend_button.grid(row=6,column=0,padx=10,pady=10,sticky=E)

ClearLending=Button(Lending_tab,text="Clear Fields",bg="Yellow",fg="black",font=("Times New Roman",16,"bold"),command=ClearLendingTabs)
ClearLending.grid(row=6,column=1,padx=10,pady=10,sticky=E)

DeleteLending=Button(Show_lending,text="Delete Selected",bg="Yellow",fg="black",font=("Times New Roman",16,"bold"),command=Delete_Lending)
DeleteLending.grid(row=6,column=0,padx=10,pady=10,sticky=W)

UpdateReturnDate=Button(Show_lending,text="Update Selected ",bg="Yellow",fg="black",font=("Times New Roman",16,"bold"),command=update_return_date)
UpdateReturnDate.grid(row=6,column=1,padx=10,pady=10,sticky=E)


Lending_tree=ttk.Treeview(Show_lending,columns=("Book_title","Borrower_Name","Borrow_date","Return_date"),show='headings')
for records in ("Book_title","Borrower_Name","Borrow_date","Return_date"):
    Lending_tree.heading(records,text=records)

Lending_tree.grid(row=2,column=0,columnspan=6,pady=10)
view_LendingRecord()
root.mainloop()