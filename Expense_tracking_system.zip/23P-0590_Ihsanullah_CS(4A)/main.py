from tkinter import *
from tkinter import messagebox, ttk
import sqlite3
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Database setup
conn = sqlite3.connect("User.db")
cursor = conn.cursor()

# Global variables for the table widgets
expenseTable = None
IncomeTable = None

########################### function to Add a new Expense record to table ####################
def ADDEXPENSE(category, date,amount,description):
    global expenseTable
    if not amount or not category or not description:
        messagebox.showwarning("Error", "All fields are required")
        return
    try:
        cursor.execute("INSERT INTO EXPENSES (CATEGORY,DATE,AMOUNT, DESCRIPTION) VALUES (?,?,?,?)",
                     (category,date,amount, description))
        conn.commit()
        messagebox.showinfo("Success", "Expense added successfully")
        refresh_tables()
    except Exception as e:
        messagebox.showerror("Error", f"Failed to add expense: {str(e)}")

##################function to Add a new Record to THe Table #################
def ADDINCOME(amount, date, source):
    global IncomeTable
    if not amount or not source:
        messagebox.showwarning("Error", "All fields are required")
        return
    try:
        cursor.execute("INSERT INTO INCOME (AMOUNT, DATE, SOURCE) VALUES (?,?,?)",
                     (amount, date, source))
        conn.commit()
        messagebox.showinfo("Success", "Income added successfully")
        refresh_tables()
    except Exception as e:
        messagebox.showerror("Error", f"Failed to add income: {str(e)}")


def refresh_tables():
    global expenseTable, IncomeTable
    
    # Clear existing data
    for item in expenseTable.get_children():
        expenseTable.delete(item)
    for item in IncomeTable.get_children():
        IncomeTable.delete(item)
    
    # Load expense data
    cursor.execute("SELECT EXPENSE_ID,CATEGORY,DATE,AMOUNT,DESCRIPTION FROM EXPENSES")
    for row in cursor.fetchall():
        expenseTable.insert("", "end", values=row)
    
    # Load income data
    cursor.execute("SELECT INCOME_ID,AMOUNT,DATE,SOURCE FROM INCOME")
    for row in cursor.fetchall():
        IncomeTable.insert("", "end", values=row)


def show_visualization():
    # Create a new window for visualization
    vis_window = Toplevel()
    vis_window.title("Data Visualization")
    vis_window.geometry("800x600")
    
    # Get expense data by category
    cursor.execute("SELECT CATEGORY, SUM(AMOUNT) FROM EXPENSES GROUP BY CATEGORY")
    expense_data = cursor.fetchall()
    categories = [row[0] for row in expense_data]
    exp_amounts = [row[1] for row in expense_data]
    
    # Get income data by source
    cursor.execute("SELECT SOURCE, SUM(AMOUNT) FROM INCOME GROUP BY SOURCE")
    income_data = cursor.fetchall()
    sources = [row[0] for row in income_data]
    inc_amounts = [row[1] for row in income_data]
    
    # Create figure with two subplots
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))
    fig.suptitle('Expense and Income Analysis')
    
    # Expense pie chart
    if categories and exp_amounts:
        ax1.pie(exp_amounts, labels=categories, autopct='%1.1f%%', startangle=120)
        ax1.set_title('Expenses by Category')
        ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
    else:
        ax1.text(0.5, 0.5, 'No expense data available', ha='center', va='center')
    
    # Income pie chart
    if sources and inc_amounts:
        ax2.pie(inc_amounts, labels=sources, autopct='%1.1f%%', startangle=120)
        ax2.set_title('Income by Source')
        ax2.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
    else:
        ax2.text(0.5, 0.5, 'No income data available', ha='center', va='center')
    
    # Embed the figure in the Tkinter window
    canvas = FigureCanvasTkAgg(fig, master=vis_window)
    canvas.draw()
    canvas.get_tk_widget().pack(side=TOP, fill=BOTH, expand=1)
    
    # Close button
    close_button = Button(vis_window, text="Close", command=vis_window.destroy)
    close_button.pack(pady=10)

################# function to handle the frame when login was successfulled ####################
def successfullLogin(name):
    global expenseTable, IncomeTable
    
    root = Tk()
    root.title(f"Expense Tracking System - {name}")
    root.geometry("1300x700")
    root.resizable(False, False)
    
    # Welcome message and buttons frame
    top_frame = Frame(root, bg="#0096DC")
    top_frame.pack(side=TOP, fill=X, pady=10)
    
    Welcomemsg = Label(top_frame, text=f"Welcome {name}!", font=("Arial", 18, "bold"), 
                      bg="#0096DC", fg="white")
    Welcomemsg.pack(side=LEFT, padx=20)
    
    # Logout button
    logout_btn = Button(top_frame, text="Logout", font=("Arial", 12, "bold"),
                       bg="yellow", fg="black", command=lambda: [root.destroy(), login_screen()])
    logout_btn.pack(side=RIGHT, padx=20)
    
    # Visualize Data button
    visualize_btn = Button(top_frame, text="Visualize Data", font=("Arial", 12, "bold"),
                          bg="green", fg="white", command=show_visualization)
    visualize_btn.pack(side=RIGHT, padx=10)
    
    # Main container
    main_container = Frame(root)
    main_container.pack(fill=BOTH, expand=True)
    main_container.grid_columnconfigure(0, weight=1)
    main_container.grid_columnconfigure(1, weight=1)
    main_container.grid_rowconfigure(0, weight=1)
    
    # Left Frame - Input Forms
    LeftFrame = LabelFrame(main_container, bg="#0096DC", fg="white")
    LeftFrame.grid(row=0, column=0, sticky="nsew")
    
    # Expense Form
    AddExpenseLabel=Label(LeftFrame,text="Add Expense",bg="white",fg="black",font=("Times New Roman",14,"bold"))
    AddExpenseLabel.grid(row=0,column=0,pady=20)
    
    Amount=Label(LeftFrame,text="Amount:",font=("Arial",12,"bold"),bg="#0096DC")
    Amount_input=Entry(LeftFrame,font=("Times New Roman",12,"bold"))
    Amount.grid(row=1,column=0,padx=5,pady=10,sticky="e")
    Amount_input.grid(row=1,column=2,padx=5,pady=10,sticky="ew")
    
    Category=Label(LeftFrame,text="Category:",font=("Arial",12,"bold"),bg="#0096DC")
    Category_input=Entry(LeftFrame,font=("Times New Roman",12,"bold"))
    Category.grid(row=2,column=0,padx=5,pady=10,sticky="e")
    Category_input.grid(row=2,column=2,padx=5,pady=10,sticky="ew")
    
    Description=Label(LeftFrame,text="Description:",font=("Arial",12,"bold"),bg="#0096DC")
    Description_input=Entry(LeftFrame,font=("Times New Roman",12,"bold"))
    Description.grid(row=3,column=0,padx=5,pady=10,sticky="e")
    Description_input.grid(row=3,column=2,padx=5,pady=10,sticky="ew")
    
    Date=Label(LeftFrame,text="Date:",font=("Arial",12,"bold"),bg="#0096DC")
    Date_input=Entry(LeftFrame,font=("Times New Roman",12,"bold"))
    Date.grid(row=4,column=0,padx=5,pady=10,sticky="e")
    Date_input.grid(row=4,column=2,padx=5,pady=10,sticky="ew")
    
    AddExpense_btn=Button(LeftFrame,text="Add Expense",font=("Arial",14,"bold"),fg="blue",bg="#0096DC",command=lambda:ADDEXPENSE(Category_input.get(),Date_input.get(),Amount_input.get(),Description_input.get()))
    AddExpense_btn.grid(row=6,column=2,padx=5,pady=10,sticky="e")
    
    #to take from user about Income
    AddIncomeLabel=Label(LeftFrame,text="Add Income",bg="white",fg="black",font=("Times New Roman",16,"bold"))
    AddIncomeLabel.grid(row=7,column=0,columnspan=2,pady=20)
    
    IncomeAmount=Label(LeftFrame,text="Amount:",font=("Arial",12,"bold"),bg="#0096DC")
    IncomeAmount_input=Entry(LeftFrame,font=("Times New Roman",12,"bold"))
    IncomeAmount.grid(row=8,column=0,padx=5,pady=10,sticky="e")
    IncomeAmount_input.grid(row=8,column=2,padx=5,pady=10,sticky="ew")
    
    IDate=Label(LeftFrame,text="Date:",font=("Arial",12,"bold"),bg="#0096DC")
    IDate_input=Entry(LeftFrame,font=("Times New Roman",12,"bold"))
    IDate.grid(row=9,column=0,padx=5,pady=10,sticky="e")
    IDate_input.grid(row=9,column=2,padx=5,pady=10,sticky="ew")
    
    Source=Label(LeftFrame,text="Source:",font=("Arial",12,"bold"),bg="#0096DC")
    Source_input=Entry(LeftFrame,font=("Times New Roman",12,"bold"))
    Source.grid(row=10,column=0,padx=5,pady=10,sticky="e")
    Source_input.grid(row=10,column=2,padx=5,pady=10,sticky="ew")
    
    AddIncome_btn=Button(LeftFrame,text="Add Income",font=("Arial",14,"bold"),fg="blue",bg="#0096DC",command=lambda:ADDINCOME(IncomeAmount_input.get(),IDate_input.get(),Source_input.get()))
    AddIncome_btn.grid(row=11,column=2,padx=5,pady=10,sticky="e")
    
    
    # Right Frame - Tables
    RightFrame = Frame(main_container, bg="#0096DC")
    RightFrame.grid(row=0, column=1, sticky="nsew",pady=10)
    RightFrame.grid_rowconfigure(0, weight=1)
    RightFrame.grid_rowconfigure(1, weight=1)
    RightFrame.grid_columnconfigure(0, weight=1)
    
    # Expense Table
    ExpenseFrame = LabelFrame(RightFrame, text="Expense Records", bg="#0096DC", fg="white")
    ExpenseFrame.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
    
    expenseTable = ttk.Treeview(ExpenseFrame, columns=("ID", "Category", "Date", "Amount", "Description"), 
                              show="headings", height=8)
    expenseTable.heading("ID", text="ID")
    expenseTable.heading("Category", text="Category")
    expenseTable.heading("Date", text="Date")
    expenseTable.heading("Amount", text="Amount")
    expenseTable.heading("Description", text="Description")
    expenseTable.pack(fill=BOTH, expand=True)
    
    # Income Table
    IncomeFrame = LabelFrame(RightFrame, text="Income Records", bg="#0096DC", fg="white")
    IncomeFrame.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
    
    IncomeTable = ttk.Treeview(IncomeFrame, columns=("ID", "Amount", "Date", "Source"), 
                             show="headings", height=8)
    IncomeTable.heading("ID", text="ID")
    IncomeTable.heading("Amount", text="Amount")
    IncomeTable.heading("Date", text="Date")
    IncomeTable.heading("Source", text="Source")
    IncomeTable.pack(fill=BOTH, expand=True)
    
    # Load initial data
    refresh_tables()
    root.mainloop()

def login_screen():
    global user_name_input, password_input
    
    root = Tk()
    root.title("Expense Tracking System")
    root.maxsize(600, 500)
    root.minsize(600, 500)
    root.grid_columnconfigure(0, weight=1)
    root.grid_columnconfigure(1, weight=1)
    root.grid_rowconfigure(0, weight=1)

    # Constructing the first frame, frame1
    frame1 = LabelFrame(root, bg="grey", fg="white")
    frame1.grid(row=0, column=0, sticky="nsew")

    # Constructing the button b1 in frame1
    b1 = Button(frame1, text="Shany Khan", bg="black",font=("Times New Roman",18,"bold"))
    b1.pack(pady=50)

    # Add a label to frame1
    button2 = Label(frame1, text="MY EXPENSE TRACKING SYSTEM", bg="black", fg="white")
    button2.pack()

    # Constructing the second frame, frame2
    frame2 = LabelFrame(root, bg="#0096DC")
    frame2.grid(row=0, column=1, sticky="nsew")

    button1=Label(frame2,text="LOGIN HERE",bg="white",fg="#0096DC",font=("Times New Roman",24))
    button1.pack(padx=10,pady=50)

    user_name=Label(frame2,text="Email",bg="white",fg="#0096Dc",font=("Times New Roman",18,"bold")).pack(padx=5,pady=10)
    user_name_input=Entry(frame2,font="Arial,8,bold")
    user_name_input.pack(ipady=4,ipadx=2)

    password=Label(frame2,text="Password",bg="white",fg="#0096Dc",font=("Times New Roman",18,"bold"))
    password.pack(padx=10,pady=10)
    password_input=Entry(frame2,width=40,show='*')
    password_input.pack(ipady=5,ipadx=2)

    Button(frame2,text="Log IN",font=("Times New Roman",16,"bold","italic"),bg="blue",fg="white",command=lambda:LOGINPAGE(root)).pack(pady=(10,10),ipadx=30)

    REGISTER=Button(frame2,text="REISTER",font=("Times New Roman",16,"bold","italic"),bg="blue",fg="white",command=REGISTERPAGE)
    REGISTER.pack(pady=(5,5),ipadx=30)
    
    # Start the blinking effect
    blink_button(b1, root)

    root.mainloop()

def blink_button(button, root):
    current_color = button.cget("bg")
    if current_color == "black":
        button.config(bg="white")
    else:
        button.config(bg="black")
    root.after(500, lambda: blink_button(button, root))

###########################################################################################################################################
#function to handle login page
def LOGINPAGE(root_window):
    name=user_name_input.get()
    pswd=password_input.get()
    if not name or not pswd:
        messagebox.showwarning("Warning","UserName or Password Can't be Empty")
        return
    else:
        cursor.execute("Select * from USERS where USER_NAME = ? and PASSWORD=?",(name,pswd))
        check=cursor.fetchone()
        if check:
            messagebox.showinfo("Success","Login Successful")
            root_window.destroy()
            successfullLogin(name)
        else:
            messagebox.showwarning("Warning","UserName Doesn't Exist or Password is Incorrect")
            return
 
 
 ###############################################################################################################################
 #function to handle Register page
def REGISTERPAGE():
    name=user_name_input.get()
    passwd=password_input.get()
    
    if not name or not passwd:
        messagebox.showwarning("Warning","UserName or password cannot be EMPTY!")
        return
    else:
        try:
            cursor.execute("Insert into USERS(USER_NAME,PASSWORD) VALUES(?,?)",(name,passwd))
            conn.commit()
            messagebox.showinfo("Success","User Register Successfully")
        except sqlite3.IntegrityError:
            messagebox.showwarning("Warning","UserName Already Registered!")

# Start the application
if __name__ == "__main__":
    login_screen()