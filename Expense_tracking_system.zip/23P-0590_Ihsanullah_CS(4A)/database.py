import sqlite3
conn=sqlite3.connect('User.db')

#initlize cursor on the database User.db
CURSOR=conn.cursor()

#ENABLING FOREIGN KEY SUPPORT
conn.execute("PRAGMA foreign_keys = ON;")
#create table USers
CURSOR.execute('''
 CREATE TABLE USERS(
        USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
        USER_NAME TEXT UNIQUE NOT NULL,
        PASSWORD TEXT NOT NULL
         );
 ''')

conn.commit()
#CREATE TABLE EXPENSES
CURSOR.execute('''
 CREATE TABLE EXPENSES(
             EXPENSE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
             USER_ID INTEGER NOT NULL,
             CATEGORY TEXT NOT NULL,
             DATE TEXT NOT NULL,
             AMOUNT REAL NOT NULL,
             DESCRIPTION TEXT,
             FOREIGN KEY (USER_ID) REFERENCES USERS(USER_ID) ON DELETE CASCADE
            );
 ''')
conn.commit()
#CEATE TABLE INCOME
CURSOR.execute('''
   CREATE TABLE INCOME(
                    INCOME_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    USER_ID INTEGER,
                    AMOUNT REAL NOT NULL,
                    DATE TEXT NOT NULL,
                    SOURCE TEXT NOT NULL,
                    FOREIGN KEY(USER_ID) REFERENCES USERS(USER_ID) ON DELETE CASCADE
                 );
 ''')

conn.commit()
conn.close()
print("Tables Created Successfully\n");