<?php 
    include 'connection.php';

    $action = $_GET['action'];
    $order_id = $_GET['order_id'];
    echo $order_id;
    
    if ($action == 1){
      $sql = "UPDATE ORDERS SET status=\"Approved\" WHERE order_id = $order_id;";
      $conn->query($sql);
    } 
    
    else if ($action == 2){
      $sql = "UPDATE ORDERS SET status=\"Cancel\" WHERE order_id = $order_id;";
      $conn->query($sql);
    }
?>