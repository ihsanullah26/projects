<?php
     include '../connection.php';
     $getproductid=$_GET['product_id'];
     $sql="DELETE FROM PRODUCTS where product_id=$getproductid;";
     $conn->query($sql);
     header('Location:../products.php');
?>

