<?php

    include 'connection.php';

    session_start();

    // use sessions to preserve product id
    

    //if the user made changes in data and clicked 'Update data'
    if(isset($_POST['update']))
    {   
        $pid = $_SESSION['pid'];
        $prod_name = $_POST['phone_name'];
        $prod_color = $_POST['phone_color'];
        $prod_ram = $_POST['phone_ram'];
        $prod_storage = $_POST['phone_storage'];
        $prod_battery = $_POST['phone_battery'];
        $prod_price = $_POST['phone_price'];
        $image_path = $_POST['image-name'];
        $brand_name=$_POST['brands'];

        $brand_id_query = "SELECT brand_id 
        FROM BRANDS 
        WHERE brand_name = \"$brand_name\";";
        
        echo "$brand_id_query <br>";


        // fetch brand id value
        $brand_id_value = (($conn->query($brand_id_query))->fetch_assoc())['brand_id'];
        //update query
        $sql = "UPDATE PRODUCTS SET 
        p_name=\"$prod_name\",color=\"$prod_color\",ram=$prod_ram,
        disk=$prod_storage,battery_capacity=$prod_battery,PRICE=$prod_price,
        image_path=\"$image_path\",brand_id=$brand_id_value where product_id=$pid;";

        if($conn->query($sql))
        {
                header('Location: products.php');
        }
    
    session_destroy();

} else {
    $_SESSION['pid'] = $_GET['product_id'];
}

    //fetching old data to show in placeholder for editing
    //$prod_id = $_GET['product_id'];
    $prod_id = $_SESSION['pid'];
    
    $result = $conn->query("SELECT * FROM PRODUCTS WHERE product_id = $prod_id;");

    $row = $result->fetch_assoc();
     
    $product_name = $row['p_name'];
    $product_color = $row['color'];
    $product_ram = $row['ram'];
    $product_storage = $row['disk'];
    $product_battery = $row['battery_capacity'];
    $product_price = $row['PRICE'];
    $image_path = $row['image_name'];
    $string = explode('/',$image_path);


    echo "External here"
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/admin.css" />
</head>
<body>
<?php include 'sidebar.php'; ?>
<div id="right-container">
    <h2>Edit Product Details</h2>
    <div id="Add-product">
        <form action="product-edit-page.php" method="POST">
             <h5>Product Name</h5>
             <input type="text" id="phone" name="phone_name" value="<?=$product_name?>" required ="Galaxy A05">
             <h5>Color</h5>
             <input type="text" id="color" name="phone_color" value="<?=$product_color?>" required placeholder="Blue">
             <h5>RAM</h5>
             <input type="number" id="number" name="phone_ram" value="<?=$product_ram?>" required placeholder="4 GB">
             <h5>Storage</h5>
             <input type="number" id="storage" name="phone_storage" value="<?=$product_storage?>" required placeholder="64 GB">
             <h5>Battery</h5>
             <input type="number" id="battery" name="phone_battery" value="<?=$product_battery?>" required placeholder="5000mAH">
             <h5>Price</h5>
             <input type="number" id="price" name="phone_price" value="<?=$product_price?>" required placeholder="50000 PKR">
             <h5>Brand</h5>
            <select name="brands" id="drop-down-menu">
                <?php
                    include 'connection.php'; 
                    $result = $conn->query("SELECT * FROM BRANDS;");
                    while ($row = $result->fetch_assoc()) {?>

                    <option value="<?=$row['brand_name']?>"><?=$row['brand_name']?></option>
                <?php } ?>
            </select>
            <button name="update" type="submit">Update Data</button>
        </form>

    </div>
</div>
</body>
</html>