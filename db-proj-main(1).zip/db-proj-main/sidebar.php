
<?php session_start() ?>

<div id="left-container">
        <div id="admin-ico">
          <img src="images/admin-ico" alt="" />
          <b><?=$_SESSION['usrname']?></b>
          <br />Admin
        </div>
  
        <a href="admin.php">
          <div class="frame" id="dashboard-frame">
            <img class="list-img" src="images/dashboard-ico" alt="" />
            <h4>Dashboard</h4>
          </div>
        </a>
  
        <a href="users.php">
          <div class="frame" id="users-frame">
            <img class="list-img" src="images/users-ico" alt="" />
            <h4>Users</h4>
          </div>
        </a>
  
        <a href="products.php">
          <div class="frame" id="product-frame">
            <img class="list-img" src="images/products-ico" alt="" />
            <h4>Product</h4>
          </div>
        </a>
  
        <a href="orders.php">
          <div class="frame" id="order-frame">
            <img class="list-img" src="images/orders-ico" alt="" />
            <h4>Orders</h4>
          </div>
        </a>
      </div>
    </div>