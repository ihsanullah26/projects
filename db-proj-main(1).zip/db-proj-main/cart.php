<?php
session_start();
 include 'connection.php';

    if($_GET['prod_id'] != '')
    {
         $product_tobeDelete_id=$_GET['prod_id'];
         $sql="DELETE FROM CART where product_id=$product_tobeDelete_id;";
         $conn->query($sql);
    }
    
      if($_SESSION['usrname']!='')
      {
        $user_name=$_SESSION['usrname'];
        $usr_id=(($conn->query("Select * from users WHERE username=\"$user_name\";"))->fetch_assoc())['user_id']; 
        $result=$conn->query("SELECT * from CART NATURAL JOIN PRODUCTS WHERE user_id=$usr_id;");
        $total_amount = $conn->query("SELECT SUM(PRICE * qty) AS TOTAL_PRICE from CART NATURAL JOIN PRODUCTS WHERE user_id=$usr_id")->fetch_assoc()['TOTAL_PRICE'];
        }
      else
      {
        header('Location:test/login.php');
      }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/cart.css">
</head>
<body>
    <?php include 'navbar.php';?>

    <h1>My Cart</h1>
    <ul>
        <?php
        while($row=$result->fetch_assoc())
        {
            $product_id=$row['product_id'];
            $b_id=$row['brand_id'];
            $image_name=$row['image_path'];
            $brand_name=(($conn->query("Select brand_name from BRANDS where brand_id=$b_id;"))->fetch_assoc())['brand_name'];
            ?>
        
        <li class="cart-items">
            <img src="images/<?=$brand_name?>/<?=$image_name?>" alt="">
            <ol>
                <li id="title" ><?=$row['p_name']?></li>
                <li>Product ID :<?=$row['product_id']?> </li>
                <li>RAM : <?=$row['ram']?> GB</li>
                <li>Storage : <?=$row['disk']?> GB</li>
                <li>Color : <?=$row['color']?></li>
                <li><b>Quantity: <?=$row['qty']?></b></li>
            </ol>
            <h2>PKR <?=$row['PRICE']?></h2>
            <a href="cart.php?prod_id=<?=$product_id?>">Remove</a>
        </li>
        <?php }?>
    </ul>
        
    <div id="checkout-box">
        <a href="order_success.php"><button class="buttonClass">Check out</button></a>
        <h3>Total : <?=$total_amount?></h3>
    </div>

</body>

</html>