<?php  $usrname = $_GET['username'];?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>
    <?php include 'connection.php';?>
  <div id="right-container">
    <!-- Manage users-->
    
    <h2>Recently Registered Users</h2>
    <table>
      <tr>
        <th>Username</th>
        <th>Email</th>
        <th>Phone Number</th>
        <th>Date Registered</th>
      </tr>
      <?php
            $result = $conn->query("SELECT * FROM users where isAdmin=0 ORDER BY join_date DESC ;;");
            while ($row = $result->fetch_assoc()) {?>
        <tr>
          <td><?=$row['username']?></td>
          <td><?=$row['email']?></td>
          <td><?=$row['phone_no']?></td>
          <td><?=$row['join_date']?></td>
      </tr>
      <?php } ?>
    </table>


    <h2>Recently Added Products</h2>
    <table>
      <tr>
        <th>Product Name</th>
        <th>Brand Name</th>
        <th>Price</th>
        <th>Date Added</th>
      </tr>
      <?php
           
            $result = $conn->query("SELECT * FROM PRODUCTS ORDER BY date_added DESC ;;");
            while ($row = $result->fetch_assoc()) {
              $b_id=$row['brand_id'];
              $brand_name=($conn->query("Select brand_name from BRANDS where brand_id=$b_id;")->fetch_assoc())['brand_name'];
              ?>
        <tr>
          <td><?=$row['p_name']?></td>
          <td><?=$brand_name?></td>
          <td><?=$row['PRICE']?></td>
          <td><?=$row['date_added']?></td>
      </tr>
      <?php } ?>
    </table>


    <h2>Recently Placed Orders</h2>

    <table>
      <tr>
        <th>Order ID</th>
        <th>Order Date</th>
        <th>Username</th>
        <th>Status</th>
      </tr>
      <?php
           $result = $conn->query("SELECT * FROM ORDERS ORDER BY order_date DESC;");
           
           while ($row = $result->fetch_assoc()) { 
            $user_id = $row['user_id'];
            $username = $conn->query("SELECT * FROM users WHERE user_id = $user_id")->fetch_assoc()['username'];
            ?>
       <tr>
         <td><?=$row['order_id']?></td>
         <td><?=$row['order_date']?></td>
         <td><?=$username?></td>
         <td><?=$row['status']?></td>
     </tr>
     <?php } ?>
    </table>
  </div>
  <?php include 'sidebar.php'; ?>
</body>
</html>