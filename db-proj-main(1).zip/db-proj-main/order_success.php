<?php
    session_start();
    include 'connection.php';
    //fetch the username from session
    $user_name=$_SESSION['usrname'];
    //fetch user id
    $usr_id=(($conn->query("Select * from users WHERE username=\"$user_name\";"))->fetch_assoc())['user_id']; 
    //fetch products selected by the user
    $result=$conn->query("SELECT * from CART NATURAL JOIN PRODUCTS WHERE user_id=$usr_id;");
    //calculate the total order amount
    $total_amount = $conn->query("SELECT SUM(PRICE*qty) AS TOTAL_PRICE from CART NATURAL JOIN PRODUCTS WHERE user_id=$usr_id")->fetch_assoc()['TOTAL_PRICE'];
    //place the order and insert into order table

    if ($total_amount != ''){
      $sql="INSERT INTO ORDERS(user_id,total_amount) values($usr_id,$total_amount);";
      $place_order=$conn->query($sql);
    } else {
      header('Location: cart.php');
    }
    
    //filling the bridge table (ORDER_PRODUCTS) 
    $order_id = $conn->query("SELECT MAX(order_id) AS ORDER_ID FROM ORDERS;")->fetch_assoc()['ORDER_ID'];
    while ($row = $result->fetch_assoc()){

        $product_id = $row['product_id'];
        $qty = $row['qty'];
        $insert_query_bridge_table = "INSERT INTO ORDER_PRODUCTS VALUES ($product_id,$qty,$order_id);";
        $conn->query($insert_query_bridge_table);
    }

    // empty cart data
    $empty_cart="DELETE FROM CART where user_id=$usr_id;";
    $conn->query($empty_cart);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Order Confirmation</title>
  <link rel="stylesheet" href="css/styles.css">
  <style>
        /* body {
        background-color: #fff;
        color: #000;
        font-family: Arial, sans-serif;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin: 0;
        } */
    .message {
        margin-top:10%;
      text-align: center;
    }
    .message h2 {
      font-size: 2rem;
      margin-bottom: 0.5rem;
    }
    .message p {
      font-size: 1rem;
      color: #333;
    }
  </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
  <div class="message">
    <h2>Order Placed Successfully</h2>
    <p>Thank you for your purchase.</p>
  </div>
</body>
</html>
