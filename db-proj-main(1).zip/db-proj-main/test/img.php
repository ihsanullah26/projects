<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <label for="image-path" style="display:block;margin">Choose Product Image

    </label>
    <input type="file" id="image-path" accept="image/png, image/jpeg">
</body>
</html>