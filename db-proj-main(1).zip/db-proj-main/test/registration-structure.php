<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="./registration.css">
</head>
<body>

    <div class="glass-container">
        <div class="login-box">
                <h2 class="gradient-text">Register</h2>
                <form action="register-user-logic.php" method="POST">
                    <input type="text" id="username" name="username" required placeholder="Username">
                    <input type="email" id="email" name="email" required placeholder="Email">
                    <input type="password" id="password" name="password" required placeholder="Password">
                    <input type="number" name="phone_no" id="Number" required placeholder="Phone Number">
                    <input type="text" id="Address" name="address" required placeholder="Address">
                    <button type="submit">Register</button>
                    <p>Already Have an Account? <a id="register" class="gradient-text" href="login.php" id="register">Login</a></p>
                </form>
        </div>
    </div>
</body>
</html>