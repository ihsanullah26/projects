<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Registration Successful</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background:#e8e1cb;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .message-box {
      background: #ffffff;
      color: #000000;
      padding: 30px 40px;
      border-radius: 10px;
      box-shadow: 0 0 20px rgba(255, 255, 255, 0.1);
      text-align: center;
    }

    .message-box h1 {
      margin-bottom: 10px;
      font-size: 24px;
    }

    .message-box p {
      margin-bottom: 20px;
      font-size: 16px;
    }

    .message-box a {
      display: inline-block;
      padding: 10px 20px;
      background-color: #000000;
      color: #ffffff;
      text-decoration: none;
      border: 2px solid #000000;
      border-radius: 5px;
      transition: all 0.3s ease;
      font-weight: bold;
    }

    .message-box a:hover {
      background-color: transparent;
      color: #000000;
    }
  </style>
</head>
<body>

  <div class="message-box">
    <h1>Registration Successful</h1>
    <p>Your account has been created. You can now log in.</p>
    <a href="login.php">Go to Login</a>
  </div>

</body>
</html>
