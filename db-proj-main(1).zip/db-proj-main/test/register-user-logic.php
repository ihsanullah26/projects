<?php

    session_start();

    // first connect to the database
    include '../connection.php';

    // GET values from page
    $usrname = $_REQUEST['username'];
    $email = $_REQUEST['email'];
    $passwd = $_REQUEST['password'];
    $phone_no = $_REQUEST['phone_no'];
    $address = $_REQUEST['address'];
    
    // write insert query
    $sql = "INSERT INTO users (username,email,password,phone_no,address)
    VALUES (\"$usrname\",\"$email\",\"$passwd\",$phone_no,\"$address\");";
    if (mysqli_query($conn, $sql)) {
        $_SESSION['message'] = "Registration Successful!";
        header('Location: registration-successful.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }


?>