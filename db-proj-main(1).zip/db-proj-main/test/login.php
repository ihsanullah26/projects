<?php
    
    include '../connection.php';

    // check if submit button has been clicked
    if (isset($_POST['submit'])) {
        
        // fetch data
        $usr = $_POST['username'];
        $pass = $_POST['password'];
        
        // check if user exists in the database
        $sql = "SELECT * FROM users
        WHERE username = \"$usr\" AND password = \"$pass\";";

// run query
        $result = $conn->query($sql);
        
        
        // check if query has return any result
        if ($result->num_rows > 0) {
            
            // start session
            session_start();
            
            // fetch row
            $row = $result->fetch_assoc();
            
            $_SESSION['usrname'] = $row['username'];
            
            // if user is admin then send him to admin page
            if ($row['isAdmin']){
                header('Location: ../admin.php?username='.$row['username']);
            } else {
                header('Location: ../index.php');
            }

        }
        else
        {
            $rs = true;
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="./login-page.css">
</head>
<body>
    <div class="glass-container">
        <div class="login-box">
                <h2 class="gradient-text">Login</h2>
                <form action="login.php" method="POST">
                    <input type="text" id="username" name="username" required placeholder="Username">
                    <input type="password" id="password" name="password" required placeholder="Password">
                    <button type="submit" name="submit" >Login</button>
                    <p>Don't Have an Account? <a id="register" class="gradient-text" href="registration-structure.php" id="register">Register</a></p>
                    <?php 
                        if ($rs) { ?>
                    
                            <h4 class="login-failed" >Login Failed </h4>
                            
                    <?php } ?>
                </form>
        </div>
    </div>
</body>
</html>