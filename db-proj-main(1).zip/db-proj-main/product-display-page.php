<?php 



    // get brand id and store in a variable
    if ($_GET['brand-radio-btn'] == ''){
        $BRAND_ID = $_GET['brand_id']; 
    } else {
        $BRAND_ID = $_GET['brand-radio-btn'];
    }  


    if (isset($_POST['filter'])){
        $FILTER = $_POST['drop-down'];
    } else {
        $FILTER = "none";
    }
    
    
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/display-page.css">
</head>
<body>

    
    <div id="sidebar">
        <h2><a href="index.php">Home</a></h2>
        <h1>Brands</h1>

        <form action="product-display-page.php" method="GET">
        <div class="radio-btns">
            
                <input type="radio" name="brand-radio-btn" value="1" id="apple" onclick="this.form.submit()" <?= $BRAND_ID == 1 ? 'checked' : ''?>>
                <label for="apple">Apple</label>
                <input type="radio" name="brand-radio-btn" value="3" id="redmi" onclick="this.form.submit()" <?= $BRAND_ID == 3 ? 'checked' : ''?>>
                <label for="redmi">Redmi</label>
                <input type="radio" name="brand-radio-btn" value="4" id="google" onclick="this.form.submit()" <?= $BRAND_ID == 4 ? 'checked' : ''?>>
                <label for="google">Google</label>
                <input type="radio" name="brand-radio-btn" value="2" id="samsung" onclick="this.form.submit()" <?= $BRAND_ID == 2 ? 'checked' : ''?>>
                <label for="samsung">Samsung</label>
            </div>
        </form>
    </div>

    
    <div id="container">
        <?php ?>
        <div id="button-Area">
            <form action="product-display-page.php?<?=$_GET['brand-radio-btn'] == '' ? 'brand_id' : 'brand-radio-btn' ?>=<?=$BRAND_ID?>" method="POST">
                <!-- <label for ="Drop-down">Sort By Price:</label> -->
                <select name="drop-down" id="Drop-down">
                    <option value="LTH" <?php echo $FILTER == "LTH" ? 'selected' : ''; ?>>Sort By Price (low to high)</option>
                    <option value="HTL" <?php echo $FILTER == "HTL" ? 'selected' : ''; ?>>Sort By Price (high to low)</option>
                </select>
                <input type="submit" name="filter" value="Filter">
            </form>
        </div>
        <ul>
            <?php 
            include 'connection.php';
            $getbrandID=$BRAND_ID;
            
            if ($FILTER == "LTH"){
                $products = $conn->query("SELECT * from PRODUCTS WHERE brand_id=$getbrandID ORDER BY PRICE ASC;");
            } else if ($FILTER =="HTL") {
                $products = $conn->query("SELECT * from PRODUCTS WHERE brand_id=$getbrandID ORDER BY PRICE DESC;");      
            } else {
                $products = $conn->query("SELECT * from PRODUCTS WHERE brand_id=$getbrandID;");      
            }


            $brand_name=(($conn->query("SELECT brand_name from BRANDS WHERE brand_id=$getbrandID;"))->fetch_assoc())['brand_name'];
            while($row=$products->fetch_assoc())
            {
            ?>
            <a href="product-page.php?p_id=<?=$row['product_id']?>">
                <li class="product">
                    <img src="images/<?=$brand_name?>/<?=$row['image_path']?>" alt="NO IMAGE">
                    <h6><?=$row['p_name']?></h6>
                    <button><?=$row['ram']?> GB</button>
                    <button><?=$row['disk']?> GB</button>
                    <h6>PKR <?=$row['PRICE']?></h6>
                </li>
            </a>            
           <?php } ?>     
        </ul>
    </div>
</body>
</html>