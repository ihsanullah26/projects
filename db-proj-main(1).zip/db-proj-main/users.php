<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="css/admin.css" />
  </head>
  <body>
    <div id="right-container">
      <!-- Manage users-->
      <h2>Manage Users</h2>
      <table>
        <tr>
          <th>Username</th>
          <th>Email</th>
          <th>Actions</th>
        </tr>

        <?php 
          include 'connection.php';
          $sql = "SELECT * FROM users WHERE isAdmin = FALSE;";
          $result = $conn->query($sql);

          while ($row = $result->fetch_assoc()) { ?>

        <tr>
          <td><?=$row['username']?></td>
          <td><?=$row['email']?></td>
          <td>
            <a href="crud-users/delete-user.php?email=<?=$row['email']?>" onclick="return confirm('Are you sure want to delete <?= $row['username'] ?> ?')"><img src="images/remove-ico" alt="" /></a>
          </td>
        </tr>

        
        <?php } ?>

      </table>
    </div>
    <?php include 'sidebar.php'; ?>
  </body>
</html>
