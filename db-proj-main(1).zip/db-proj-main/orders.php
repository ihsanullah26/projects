<?php 
    include 'connection.php';

    $action = $_GET['action'];
    $order_id = $_GET['order_id'];

    if ($action == 1){
      $sql = "UPDATE ORDERS SET status=\"Approved\" WHERE order_id = $order_id;";
      $conn->query($sql);
    } 
    
    else if ($action == 2){
      $sql = "UPDATE ORDERS SET status=\"Cancel\" WHERE order_id = $order_id;";
      $conn->query($sql);
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="css/admin.css" />
  </head>
  <body>
    <?php include 'sidebar.php';?>
    <div id="right-container">
      <!-- Manage users-->
      <h2>Manage Orders</h2>
      <table>
        <tr>
          <th>Order Id</th>
          <th>Order Date</th>
          <th>Username</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
        <?php   
        include 'connection.php';
        $result = $conn->query("SELECT * from ORDERS;");
        while($row=$result->fetch_assoc())
        {
          $user_id=$row['user_id'];
          $user_name=($conn->query("SELECT * FROM users WHERE user_id=$user_id;"))->fetch_assoc()['username'];
         ?>
        <tr>
          <td><?=$row['order_id']?></td>
          <td><?=$row['order_date']?></td>
          <td><?=$user_name?></td>
          <td><?=$row['status']?></td>
          <td class="orders-actions">
            <a href="orders.php?action=1&order_id=<?=$row['order_id']?>">Approve</a>
            <a href="orders.php?action=2&order_id=<?=$row['order_id']?>">Cancel</a>
          </td>
        </tr>
   <?php }?>
      </table>
    </div>
    <?php include 'sidebar.php'; ?>
  </body>
</html>
