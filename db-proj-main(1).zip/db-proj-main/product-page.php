<?php
  session_start();
  include 'connection.php';

  if (isset($_POST['add-to-cart']) && $_SESSION['usrname'] != ''){
      $user_name=$_SESSION['usrname'];
      $product_id=$_GET['p_id'];
        $user_id=(($conn->query("Select * from users WHERE username=\"$user_name\";"))->fetch_assoc())['user_id'];
        $quantity=$_POST['qty'];
        $insert_cart_query="INSERT INTO CART values($product_id,$user_id,$quantity);";
        $conn->query($insert_cart_query);
  }

  $product_id=$_GET['p_id'];
  $result=$conn->query("Select * from PRODUCTS where product_id=$product_id;");
  $row=$result->fetch_assoc();
  $brand_name=(($conn->query("Select * from BRANDS where brand_id=".$row['brand_id'].";"))->fetch_assoc())['brand_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="product-page.css">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <?php include 'navbar.php';?>
    <div id="left-Container">
     <img src="images/<?=$brand_name?>/<?=$row['image_path']?>" alt="#">
    </div>
    <div id="right-bottom-container">
        <h1><?=$row['p_name']?></h1>
        <h1>PKR <?=$row['PRICE']?></h1>
        <h2>Specification</h2>
        <ul>
            <li>Battery : <?=$row['battery_capacity']?> mAh</li>
            <li>RAM : <?=$row['ram']?>GB</li>
            <li>Storage :<?=$row['disk']?>GB</li>
            <li>Color :<?=$row['color']?></li>
             
        </ul>
        <form action="product-page.php?p_id=<?=$row['product_id']?>" method="POST">
            <label for="qty-counter">Quantity :  </label> 
             <input id="qty-counter" type="number" name="qty" value=1> <br>
            <input type="submit" name="add-to-cart" value="Add to Cart">
        </form>
    </div>
</body>
</html>