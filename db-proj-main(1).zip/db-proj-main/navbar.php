<!-- Navigation Bar -->
<div id="navbar">                   
    <div id="TITLE" >MobileKhareedo</div>
    <div  id="btns-holder">
                <h4 class="test"><a href="my-orders.php"><?=$_SESSION['usrname'] == '' ? '':'My Orders'?></a></h4>
                <h4 class="test"><a href="index.php?logout=1"><?=$_SESSION['usrname'] == '' ? '':'Log Out'?></a></h4>
                <!-- login-btn -->
                <a href="test/login.php" class=btns id="login-btn">
                    <img src="images/user.png" alt="">
                    <h4><?=$_SESSION['usrname'] == '' ? 'LOGIN':$_SESSION['usrname']?></h4>
                </a>
                <!-- cart-btn -->
                <a href="cart.php?cart_id=1" class=btns id="cart-btn">
                    <img src="images/cart-ico.png" alt="">
                    <h4>CART</h4>
                </a>
            </div>
        </div>
    <div id="header-top">
        <ul>
            <li> <a href="index.php">Home</a></li>
            <li> <a href="product-display-page.php?brand_id=1">Apple</a></li>
            <li> <a href="product-display-page.php?brand_id=3">Redmi</a></li>
            <li> <a href="product-display-page.php?brand_id=4">Google</a></li>
            <li> <a href="product-display-page.php?brand_id=2">Samsung</a></li>
            <li> <a href="about-us.php">About Us</a></li>
        </ul>
    </div>