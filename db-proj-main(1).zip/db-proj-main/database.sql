create table users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(20) NOT NULL UNIQUE,
    email VARCHAR(20) NOT NULL UNIQUE,
    password VARCHAR(20) NOT NULL,
    phone_no INT NOT NULL UNIQUE,
    address VARCHAR(40) NOT NULL,
    join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
);

CREATE TABLE BRANDS (
brand_id INT PRIMARY KEY,
brand_name VARCHAR(20) NOT NULL UNIQUE
);

CREATE TABLE PRODUCTS (
product_id INT PRIMARY KEY,
p_name VARCHAR(30) NOT NULL UNIQUE,
brand_id INT,
color VARCHAR(20) NOT NULL,
ram INT NOT NULL,
disk INT NOT NULL,
battery_capacity INT NOT NULL,
price INT NOT NULL,
image_path VARCHAR(50),    
date_added TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
FOREIGN KEY (brand_id) REFERENCES BRANDS(brand_id)
);

CREATE TABLE CART (
    product_id INT,
    user_id INT,
    qty INT,
);

CREATE TABLE ORDERS (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'Pending',
    user_id INT,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE ORDER_PRODUCTS(
    product_id INT,
    quantity INT,
    order_id INT,
PRIMARY KEY(product_id,order_id),

FOREIGN key(order_id) REFERENCES ORDERS(order_id)   
);