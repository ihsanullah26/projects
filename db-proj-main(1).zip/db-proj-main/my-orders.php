<?php
session_start();
 include 'connection.php';

      if($_SESSION['usrname']!='')
      {
        
        $user_name=$_SESSION['usrname'];
        $usr_id=(($conn->query("Select * from users WHERE username=\"$user_name\";"))->fetch_assoc())['user_id']; 
        $result = $conn->query("SELECT * FROM ORDERS WHERE user_id=$usr_id;");
        }
      else
      {
        header('Location:test/login.php');
      }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/cart.css">
    <link rel="stylesheet" href="css/admin.css">

</head>
<body>
    <?php include 'navbar.php';?>

    <h1>My Orders</h1>
    
    <table>
        <tr>
            <th>Order ID</th>
            <th>Order Date</th>
            <th>Status</th>
            <th>Amount</th>
        </tr>
        <?php 
        
        while ($row = $result->fetch_assoc()) { ?>
        
        <tr>
            <td><?=$row['order_id']?></td>
            <td><?=$row['order_date']?></td>
            <td><?=$row['status']?></td>
            <td><?=$row['total_amount']?></td>
        </tr>

        <?php } ?>
    </table>
        
    <div id="checkout-box">
    </div>

</body>

</html>