<?php

    // set variable values
    $username = "root";
    $password = "";
    $servername = "localhost";
    $db = "ESTORE";

    // connect to the server and database
    $conn = new mysqli($servername,$username,$password,$db);
?>