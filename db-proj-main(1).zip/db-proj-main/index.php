<?php   
    session_start();
     if($_GET['logout'] == 1)
     {
        session_destroy();
        header('Location:index.php');
     }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>MobileKhareedo</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
        <link rel="stylesheet" href="css/styles.css">
    </head>
    <body>

        <!-- include navigation bar -->
        <?php include 'navbar.php'; ?>

        <div id="banner-area">
            <div class="swiper">
                <!-- Additional required wrapper -->
                <div class="swiper-wrapper">
                    <!-- Slides -->
                    <div class="swiper-slide"><img src="images/apple-iphone16-banner" alt=""></div>
                    <div class="swiper-slide"><img src="images/galaxy-s24-ultra.jpg" alt=""></div>
                    <div class="swiper-slide"><img src="images/google-pixel-9-pro" alt=""></div>
                    <div class="swiper-slide"><img src="images/redmi-note-13" alt=""></div>
                </div>

                <!-- If we need pagination -->
                <div class="swiper-pagination"></div>

                <!-- If we need navigation buttons -->
                <!-- <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div> -->
            </div>
        </div>
        
        <div id="shop-by-brand-heading">
            <h1>Shop By Brands</h1>
        </div>

        <div id="products-area">
            <div class=product-box id="product-area-apple">
                <img src="images/product-area-images/apple" alt="">
                <h3>Apple</h3>
                <a href="product-display-page.php?brand_id=1"><input class=product-area-btn type="button" value="Explore"></a>
            </div>
            <div class=product-box id="product-area-redmi">
                <img src="images/product-area-images/redmi" alt="">
                <h3>Redmi</h3>
                <a href="product-display-page.php?brand_id=3"><input class=product-area-btn type="button" value="Explore"></a>
            </div>
            <div class=product-box id="product-area-google">
                <img src="images/product-area-images/google.jpeg" alt="">
                <h3>Google</h3>
                <a href="product-display-page.php?brand_id=4"><input class=product-area-btn type="button" value="Explore"></a>
            </div>
            <div class=product-box id="product-area-samsung">
                <img src="images/product-area-images/samsung" alt="">
                <h3>Samsung</h3>
                <a href="product-display-page.php?brand_id=2"><input class=product-area-btn type="button" value="Explore"></a>
            </div>

        </div>
        <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
        <script>
            const swiper = new Swiper('.swiper', {
            loop: true,
            autoplay: {
                delay:3000,
                disableOnInteraction: false,
            },
            
            pagination: {
                el: '.swiper-pagination',
                clickable:true,
            },

            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            });

        </script>
    </body>
</html>
