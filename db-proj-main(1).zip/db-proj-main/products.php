<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="css/admin.css" />
  </head>
  <body>
    <div id="right-container">
      <!-- Manage users-->
      <h2>Manage Products</h2>
      <a id="add-btn" href="product-add-page.php"> Add + </a>
      <table>
        <tr>
          <th>Product Name</th>
          <th>Brand Name</th>
          <th>Price</th>
          <th>Actions</th>
        </tr>
        <?php 
            include 'connection.php';
            $result = $conn->query("SELECT * FROM PRODUCTS;");

            while ($row = $result->fetch_assoc()) { 
              $brand_name = ($conn->query("SELECT BRAND_NAME FROM PRODUCTS NATURAL JOIN BRANDS WHERE product_id =\"". $row['product_id'] ."\";")->fetch_assoc())['BRAND_NAME'];

        ?>

        <tr>
          <td><?=$row['p_name']?></td>
          <td><?=$brand_name?></td>
          <td><?=$row['PRICE']?></td>
          <td>
          <a href="crud-products/delete-product.php?product_id=<?=$row['product_id']?>" onclick="return confirm('Are you sure want to delete <?= $row['p_name'] ?> ?')"><img src="images/remove-ico" alt="" /></a>
            <a href="product-edit-page.php?product_id=<?=$row['product_id']?>"><img src="images/edit-ico" alt="" /></a>
          </td>
        </tr>

        <?php } ?>
      </table>
    </div>
    <?php include 'sidebar.php'; ?>
  </body>
</html>
