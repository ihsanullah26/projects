<?php session_start() ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        p{
            margin-top:3%;
            margin-left:1%;
            font-size:20px;
        }
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/cart.css">
</head>
<body>
    <?php include 'navbar.php';?>

    <h1>About Us</h1>
    <p>Welcome to MobileKhareedo, where innovation meets convenience. We’re a team of tech enthusiasts passionate about bringing the latest and greatest mobile phones to our customers. Whether you’re looking for cutting-edge smartphones, reliable accessories, or expert advice, we’ve got you covered.
At MobileKhareedo, we believe that your phone should be more than just a device—it should be an extension of your personality and a tool that keeps you connected to what matters most. That’s why we’re committed to offering a curated selection of top-tier phones from leading brands, along with a shopping experience that’s as seamless and friendly as possible.
We pride ourselves on exceptional customer service and believe in building lasting relationships with our customers. Our knowledgeable staff is here to guide you, answer your questions, and help you find the perfect phone that fits your lifestyle.
Thank you for choosing MobileKhareedo. We’re excited to be part of your mobile journey!</p>
</body>

</html>