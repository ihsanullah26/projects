<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Message Box</title>
  <style>
    .message-box {
      width: 300px;
      margin: 100px auto;
      padding: 20px;
      background-color: #f0f8ff;
      border: 2px solid #1e90ff;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.2);
      text-align: center;
      font-family: Arial, sans-serif;
    }

    .message-box h3 {
      margin: 0 0 10px;
      color: #1e90ff;
    }

    .message-box button {
      padding: 8px 16px;
      background-color: #1e90ff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .message-box button:hover {
      background-color: #1c86ee;
    }
  </style>
</head>
<body>

<div class="message-box" id="msgBox">
  <h3>Info</h3>
  <p>This is a message box!</p>
  <button onclick="document.getElementById('msgBox').style.display='none'">OK</button>
</div>

</body>
</html>
