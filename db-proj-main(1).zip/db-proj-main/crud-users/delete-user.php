<?php
     include '../connection.php';
     $getemail=$_GET['email'];
     $sql="DELETE FROM users where email=\"$getemail\";";
     $conn->query($sql);
     header('Location: ../users.php');
     exit;
?>

