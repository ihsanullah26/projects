<?php

    include 'connection.php';

    if (isset($_POST['add'])) {
        $product_name = $_POST['phone_name'];
        $product_color = $_POST['phone_color'];
        $product_ram = $_POST['phone_ram'];
        $product_storage = $_POST['phone_storage'];
        $product_battery = $_POST['phone_battery'];
        $product_price = $_POST['phone_price'];
        $phone_brand = $_POST['brands'];
        $image_path = $_POST['image-name'];




        $brand_id_query = "SELECT brand_id 
        FROM BRANDS 
        WHERE brand_name = \"$phone_brand\";";

        // Brandsfetch brand id value
        $brand_id_value = (($conn->query($brand_id_query))->fetch_assoc())['brand_id'];
         

        $insert_query = "INSERT INTO PRODUCTS (p_name,brand_id,color,ram,disk,battery_capacity,price,image_path)
        VALUES (\"$product_name\",$brand_id_value,\"$product_color\",$product_ram,$product_storage,$product_battery,$product_price,\"$image_path\");";

        $conn->query($insert_query);
         header('Location:products.php');
        
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/admin.css" />
</head>
<body>
<?php include 'sidebar.php'; ?>
<div id="right-container">
    <h2>Add a Product</h2>
    <div id="Add-product">
        <form action="product-add-page.php" method="POST">
             <h5>Product Name</h5>
             <input type="text" id="phone" name="phone_name" required placeholder="Galaxy A05">
             <h5>Color</h5>
             <input type="text" id="color" name="phone_color" required placeholder="Blue">
             <h5>RAM</h5>
             <input type="number" id="number" name="phone_ram" required placeholder="4 GB">
             <h5>Storage</h5>
             <input type="number" id="storage" name="phone_storage" required placeholder="64 GB">
             <h5>Battery</h5>
             <input type="number" id="battery" name="phone_battery" required placeholder="5000mAH">
             <h5>Price</h5>
             <input type="number" id="price" name="phone_price" required placeholder="50000 PKR">
             <h5>Brand</h5>
            <select name="brands" id="drop-down-menu">
                <?php
                    include 'connection.php'; 
                    $result = $conn->query("SELECT * FROM BRANDS;");
                    while ($row = $result->fetch_assoc()) {?>

                    <option value="<?=$row['brand_name']?>"><?=$row['brand_name']?></option>
                <?php } ?>
            </select>
            <label for="image-name" style="text-align:center;">Choose product image</label>
            <input type="file" id="image-name" name="image-name"> 

            <button name="add" type="submit">Add </button>

        </form>

    </div>
</div>
</body>
</html>